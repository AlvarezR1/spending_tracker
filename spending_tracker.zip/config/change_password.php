<?php
require_once('config.php');
$id = $_POST['id'];
$pass = $_POST['new_password'];

$query = "UPDATE usuarios set password = '$pass' WHERE id = '$id'";
$result = $conexion->query($query);

header("location: ../index.php?message=success_pasword");

?>