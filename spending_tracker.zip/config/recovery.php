<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require '../PHPMailer/Exception.php';
require '../PHPMailer/PHPMailer.php';
require '../PHPMailer/SMTP.php';

require_once('../config.php');
$email = $_POST['email'];
$password = $_POST['password'];
$query = "SELECT * FROM usuarios where correo = '$email' AND status = 1";
$result = $conexion->query($query);
$row = $result->fetch_assoc();

if($result->num_rows > 0){
    $mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host       = 'smtp-mail.outlook.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'alvareznew19@gmail.com';
    $mail->Password   = 'nivea2020';
    $mail->Port       = 465;

    $mail->setFrom('alvareznew19@gmail.com', 'ALVAREZ');
    $mail->addAddress('alvarez200319@gmail.com', 'Usuario prueba');
    $mail->isHTML(true);
    $mail->Subject = 'Recuperacion de contraseña';
    $mail->Body    = 'Hola, este es un correo generado para solicitar tu recuperacion de contraseña, por favor, 
    visita la pagina <a href="localhost/spending_tracker/change_password.php?id='.$row['id'].'"></a>';

    $mail->send();
    header("location: ../index.php?message=ok");
} catch (Exception $e) {
    header("location: ../index.php?message=error");
}
}else{
    header("location: ../index.php?message=not_found");
}

?>